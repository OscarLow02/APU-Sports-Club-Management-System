﻿namespace Group4
{
    partial class frmUpdate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblStatus = new System.Windows.Forms.Label();
            this.tboxRoleID2 = new System.Windows.Forms.TextBox();
            this.rdFemale2 = new System.Windows.Forms.RadioButton();
            this.rdMale2 = new System.Windows.Forms.RadioButton();
            this.label10 = new System.Windows.Forms.Label();
            this.dateBirth2 = new System.Windows.Forms.DateTimePicker();
            this.label12 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.tboxEmail2 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.tboxPhone2 = new System.Windows.Forms.TextBox();
            this.tboxPassword2 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.tboxUserID2 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tboxRoleID = new System.Windows.Forms.TextBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.rdFemale = new System.Windows.Forms.RadioButton();
            this.rdMale = new System.Windows.Forms.RadioButton();
            this.label8 = new System.Windows.Forms.Label();
            this.dateBirth = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tboxEmail = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tboxPhone = new System.Windows.Forms.TextBox();
            this.tboxPassword = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tboxUserID = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.btnAdmExit = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.lblManage = new System.Windows.Forms.Label();
            this.lblCompetition = new System.Windows.Forms.Label();
            this.lblSuggestion = new System.Windows.Forms.Label();
            this.lblIncome = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.label18 = new System.Windows.Forms.Label();
            this.panel.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel14.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel
            // 
            this.panel.AutoSize = true;
            this.panel.BackColor = System.Drawing.SystemColors.Control;
            this.panel.Controls.Add(this.panel3);
            this.panel.Controls.Add(this.panel2);
            this.panel.Controls.Add(this.panel1);
            this.panel.Controls.Add(this.label1);
            this.panel.Location = new System.Drawing.Point(168, 0);
            this.panel.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.panel.Name = "panel";
            this.panel.Size = new System.Drawing.Size(878, 758);
            this.panel.TabIndex = 37;
            this.panel.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_Paint);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.lblStatus);
            this.panel3.Controls.Add(this.tboxRoleID2);
            this.panel3.Controls.Add(this.rdFemale2);
            this.panel3.Controls.Add(this.rdMale2);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.dateBirth2);
            this.panel3.Controls.Add(this.label12);
            this.panel3.Controls.Add(this.label14);
            this.panel3.Controls.Add(this.tboxEmail2);
            this.panel3.Controls.Add(this.label15);
            this.panel3.Controls.Add(this.tboxPhone2);
            this.panel3.Controls.Add(this.tboxPassword2);
            this.panel3.Controls.Add(this.label16);
            this.panel3.Controls.Add(this.tboxUserID2);
            this.panel3.Controls.Add(this.label17);
            this.panel3.Controls.Add(this.label19);
            this.panel3.Location = new System.Drawing.Point(300, 66);
            this.panel3.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(543, 631);
            this.panel3.TabIndex = 26;
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStatus.Location = new System.Drawing.Point(231, 566);
            this.lblStatus.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(0, 25);
            this.lblStatus.TabIndex = 26;
            // 
            // tboxRoleID2
            // 
            this.tboxRoleID2.Location = new System.Drawing.Point(247, 50);
            this.tboxRoleID2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tboxRoleID2.Name = "tboxRoleID2";
            this.tboxRoleID2.ReadOnly = true;
            this.tboxRoleID2.Size = new System.Drawing.Size(179, 22);
            this.tboxRoleID2.TabIndex = 25;
            // 
            // rdFemale2
            // 
            this.rdFemale2.AutoSize = true;
            this.rdFemale2.Enabled = false;
            this.rdFemale2.Location = new System.Drawing.Point(327, 232);
            this.rdFemale2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.rdFemale2.Name = "rdFemale2";
            this.rdFemale2.Size = new System.Drawing.Size(74, 20);
            this.rdFemale2.TabIndex = 23;
            this.rdFemale2.TabStop = true;
            this.rdFemale2.Text = "Female";
            this.rdFemale2.UseVisualStyleBackColor = true;
            // 
            // rdMale2
            // 
            this.rdMale2.AutoSize = true;
            this.rdMale2.Enabled = false;
            this.rdMale2.Location = new System.Drawing.Point(248, 232);
            this.rdMale2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.rdMale2.Name = "rdMale2";
            this.rdMale2.Size = new System.Drawing.Size(58, 20);
            this.rdMale2.TabIndex = 22;
            this.rdMale2.TabStop = true;
            this.rdMale2.Text = "Male";
            this.rdMale2.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(112, 287);
            this.label10.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(87, 20);
            this.label10.TabIndex = 19;
            this.label10.Text = "Birthdate :";
            // 
            // dateBirth2
            // 
            this.dateBirth2.Enabled = false;
            this.dateBirth2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateBirth2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateBirth2.Location = new System.Drawing.Point(246, 287);
            this.dateBirth2.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.dateBirth2.Name = "dateBirth2";
            this.dateBirth2.Size = new System.Drawing.Size(180, 26);
            this.dateBirth2.TabIndex = 18;
            this.dateBirth2.Value = new System.DateTime(2024, 2, 3, 23, 57, 20, 0);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(125, 230);
            this.label12.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(74, 20);
            this.label12.TabIndex = 4;
            this.label12.Text = "Gender :";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(140, 427);
            this.label14.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(61, 20);
            this.label14.TabIndex = 13;
            this.label14.Text = "Email :";
            // 
            // tboxEmail2
            // 
            this.tboxEmail2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tboxEmail2.Location = new System.Drawing.Point(247, 427);
            this.tboxEmail2.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.tboxEmail2.Name = "tboxEmail2";
            this.tboxEmail2.ReadOnly = true;
            this.tboxEmail2.Size = new System.Drawing.Size(177, 26);
            this.tboxEmail2.TabIndex = 12;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(133, 353);
            this.label15.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(66, 20);
            this.label15.TabIndex = 11;
            this.label15.Text = "Phone :";
            // 
            // tboxPhone2
            // 
            this.tboxPhone2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tboxPhone2.Location = new System.Drawing.Point(246, 353);
            this.tboxPhone2.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.tboxPhone2.Name = "tboxPhone2";
            this.tboxPhone2.ReadOnly = true;
            this.tboxPhone2.Size = new System.Drawing.Size(177, 26);
            this.tboxPhone2.TabIndex = 10;
            // 
            // tboxPassword2
            // 
            this.tboxPassword2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tboxPassword2.Location = new System.Drawing.Point(247, 170);
            this.tboxPassword2.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.tboxPassword2.Name = "tboxPassword2";
            this.tboxPassword2.ReadOnly = true;
            this.tboxPassword2.Size = new System.Drawing.Size(179, 26);
            this.tboxPassword2.TabIndex = 9;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(61, 172);
            this.label16.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(134, 20);
            this.label16.TabIndex = 8;
            this.label16.Text = "User Password :";
            // 
            // tboxUserID2
            // 
            this.tboxUserID2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tboxUserID2.Location = new System.Drawing.Point(247, 109);
            this.tboxUserID2.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.tboxUserID2.Name = "tboxUserID2";
            this.tboxUserID2.ReadOnly = true;
            this.tboxUserID2.Size = new System.Drawing.Size(179, 26);
            this.tboxUserID2.TabIndex = 7;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(123, 113);
            this.label17.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(77, 20);
            this.label17.TabIndex = 6;
            this.label17.Text = "User ID :";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(104, 50);
            this.label19.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(94, 20);
            this.label19.TabIndex = 2;
            this.label19.Text = "User Role :";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.tboxRoleID);
            this.panel2.Controls.Add(this.btnUpdate);
            this.panel2.Controls.Add(this.rdFemale);
            this.panel2.Controls.Add(this.rdMale);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.dateBirth);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.tboxEmail);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.tboxPhone);
            this.panel2.Controls.Add(this.tboxPassword);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.tboxUserID);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Location = new System.Drawing.Point(28, 66);
            this.panel2.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(235, 631);
            this.panel2.TabIndex = 3;
            // 
            // tboxRoleID
            // 
            this.tboxRoleID.Location = new System.Drawing.Point(25, 51);
            this.tboxRoleID.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tboxRoleID.Name = "tboxRoleID";
            this.tboxRoleID.ReadOnly = true;
            this.tboxRoleID.Size = new System.Drawing.Size(179, 22);
            this.tboxRoleID.TabIndex = 25;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(61, 566);
            this.btnUpdate.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(121, 42);
            this.btnUpdate.TabIndex = 24;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // rdFemale
            // 
            this.rdFemale.AutoSize = true;
            this.rdFemale.Location = new System.Drawing.Point(107, 228);
            this.rdFemale.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.rdFemale.Name = "rdFemale";
            this.rdFemale.Size = new System.Drawing.Size(74, 20);
            this.rdFemale.TabIndex = 23;
            this.rdFemale.TabStop = true;
            this.rdFemale.Text = "Female";
            this.rdFemale.UseVisualStyleBackColor = true;
            // 
            // rdMale
            // 
            this.rdMale.AutoSize = true;
            this.rdMale.Location = new System.Drawing.Point(27, 228);
            this.rdMale.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.rdMale.Name = "rdMale";
            this.rdMale.Size = new System.Drawing.Size(58, 20);
            this.rdMale.TabIndex = 22;
            this.rdMale.TabStop = true;
            this.rdMale.Text = "Male";
            this.rdMale.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(23, 259);
            this.label8.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(77, 20);
            this.label8.TabIndex = 19;
            this.label8.Text = "Birthdate";
            // 
            // dateBirth
            // 
            this.dateBirth.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateBirth.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateBirth.Location = new System.Drawing.Point(25, 291);
            this.dateBirth.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.dateBirth.Name = "dateBirth";
            this.dateBirth.Size = new System.Drawing.Size(180, 26);
            this.dateBirth.TabIndex = 18;
            this.dateBirth.Value = new System.DateTime(2024, 2, 3, 23, 57, 20, 0);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(23, 202);
            this.label3.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "Gender";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(23, 401);
            this.label7.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 20);
            this.label7.TabIndex = 13;
            this.label7.Text = "Email";
            // 
            // tboxEmail
            // 
            this.tboxEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tboxEmail.Location = new System.Drawing.Point(25, 427);
            this.tboxEmail.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.tboxEmail.Name = "tboxEmail";
            this.tboxEmail.Size = new System.Drawing.Size(177, 26);
            this.tboxEmail.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(23, 329);
            this.label6.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(56, 20);
            this.label6.TabIndex = 11;
            this.label6.Text = "Phone";
            // 
            // tboxPhone
            // 
            this.tboxPhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tboxPhone.Location = new System.Drawing.Point(27, 355);
            this.tboxPhone.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.tboxPhone.Name = "tboxPhone";
            this.tboxPhone.Size = new System.Drawing.Size(177, 26);
            this.tboxPhone.TabIndex = 10;
            // 
            // tboxPassword
            // 
            this.tboxPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tboxPassword.Location = new System.Drawing.Point(25, 164);
            this.tboxPassword.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.tboxPassword.Name = "tboxPassword";
            this.tboxPassword.Size = new System.Drawing.Size(179, 26);
            this.tboxPassword.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(23, 140);
            this.label5.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(124, 20);
            this.label5.TabIndex = 8;
            this.label5.Text = "User Password";
            // 
            // tboxUserID
            // 
            this.tboxUserID.Enabled = false;
            this.tboxUserID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tboxUserID.Location = new System.Drawing.Point(25, 104);
            this.tboxUserID.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.tboxUserID.Name = "tboxUserID";
            this.tboxUserID.Size = new System.Drawing.Size(179, 26);
            this.tboxUserID.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(21, 81);
            this.label4.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 20);
            this.label4.TabIndex = 6;
            this.label4.Text = "User ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(23, 20);
            this.label2.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "User Role";
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(567, 430);
            this.panel1.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(4, 4);
            this.panel1.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(23, 15);
            this.label1.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(167, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Update Profile";
            // 
            // btnAdmExit
            // 
            this.btnAdmExit.Location = new System.Drawing.Point(7, 723);
            this.btnAdmExit.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.btnAdmExit.Name = "btnAdmExit";
            this.btnAdmExit.Size = new System.Drawing.Size(85, 28);
            this.btnAdmExit.TabIndex = 36;
            this.btnAdmExit.Text = "Logout";
            this.btnAdmExit.UseVisualStyleBackColor = true;
            this.btnAdmExit.Click += new System.EventHandler(this.btnAdmExit_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(4, 30);
            this.label9.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(128, 42);
            this.label9.TabIndex = 34;
            this.label9.Text = "Admin";
            // 
            // lblManage
            // 
            this.lblManage.AutoSize = true;
            this.lblManage.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblManage.Location = new System.Drawing.Point(8, 189);
            this.lblManage.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.lblManage.Name = "lblManage";
            this.lblManage.Size = new System.Drawing.Size(109, 20);
            this.lblManage.TabIndex = 28;
            this.lblManage.Text = "Manage User";
            this.lblManage.Click += new System.EventHandler(this.lblManage_Click);
            // 
            // lblCompetition
            // 
            this.lblCompetition.AutoSize = true;
            this.lblCompetition.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCompetition.Location = new System.Drawing.Point(8, 443);
            this.lblCompetition.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.lblCompetition.Name = "lblCompetition";
            this.lblCompetition.Size = new System.Drawing.Size(139, 20);
            this.lblCompetition.TabIndex = 27;
            this.lblCompetition.Text = "View Competition";
            this.lblCompetition.Click += new System.EventHandler(this.lblCompetition_Click);
            // 
            // lblSuggestion
            // 
            this.lblSuggestion.AutoSize = true;
            this.lblSuggestion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSuggestion.Location = new System.Drawing.Point(7, 276);
            this.lblSuggestion.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.lblSuggestion.Name = "lblSuggestion";
            this.lblSuggestion.Size = new System.Drawing.Size(133, 20);
            this.lblSuggestion.TabIndex = 25;
            this.lblSuggestion.Text = "View Suggestion";
            this.lblSuggestion.Click += new System.EventHandler(this.lblSuggestion_Click);
            // 
            // lblIncome
            // 
            this.lblIncome.AutoSize = true;
            this.lblIncome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIncome.Location = new System.Drawing.Point(8, 360);
            this.lblIncome.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.lblIncome.Name = "lblIncome";
            this.lblIncome.Size = new System.Drawing.Size(104, 20);
            this.lblIncome.TabIndex = 26;
            this.lblIncome.Text = "View Income";
            this.lblIncome.Click += new System.EventHandler(this.lblIncome_Click);
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.AliceBlue;
            this.panel14.Controls.Add(this.panel15);
            this.panel14.Controls.Add(this.label18);
            this.panel14.Location = new System.Drawing.Point(7, 506);
            this.panel14.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(159, 60);
            this.panel14.TabIndex = 25;
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.Azure;
            this.panel15.Location = new System.Drawing.Point(135, 0);
            this.panel15.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(25, 60);
            this.panel15.TabIndex = 22;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(13, 19);
            this.label18.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(115, 20);
            this.label18.TabIndex = 21;
            this.label18.Text = "Update Profile";
            // 
            // frmUpdate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1049, 675);
            this.Controls.Add(this.lblManage);
            this.Controls.Add(this.panel14);
            this.Controls.Add(this.panel);
            this.Controls.Add(this.lblSuggestion);
            this.Controls.Add(this.lblCompetition);
            this.Controls.Add(this.lblIncome);
            this.Controls.Add(this.btnAdmExit);
            this.Controls.Add(this.label9);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.MinimumSize = new System.Drawing.Size(539, 436);
            this.Name = "frmUpdate";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmUpdate";
            this.Load += new System.EventHandler(this.frmUpdate_Load);
            this.panel.ResumeLayout(false);
            this.panel.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnAdmExit;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblManage;
        private System.Windows.Forms.Label lblCompetition;
        private System.Windows.Forms.Label lblSuggestion;
        private System.Windows.Forms.Label lblIncome;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.RadioButton rdFemale;
        private System.Windows.Forms.RadioButton rdMale;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DateTimePicker dateBirth;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tboxEmail;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tboxPhone;
        private System.Windows.Forms.TextBox tboxPassword;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tboxUserID;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox tboxRoleID2;
        private System.Windows.Forms.RadioButton rdFemale2;
        private System.Windows.Forms.RadioButton rdMale2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DateTimePicker dateBirth2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox tboxEmail2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox tboxPhone2;
        private System.Windows.Forms.TextBox tboxPassword2;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox tboxUserID2;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox tboxRoleID;
        private System.Windows.Forms.Label lblStatus;
    }
}