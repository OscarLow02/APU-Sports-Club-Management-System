﻿namespace Group4
{
    partial class frmupdate_coach
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnLogout = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lblUpdate = new System.Windows.Forms.Label();
            this.lblCoach = new System.Windows.Forms.Label();
            this.lblRecom = new System.Windows.Forms.Label();
            this.lblManage = new System.Windows.Forms.Label();
            this.lblperform = new System.Windows.Forms.Label();
            this.lblPay = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.txtPhone = new System.Windows.Forms.TextBox();
            this.lblPhone = new System.Windows.Forms.Label();
            this.txtBDate = new System.Windows.Forms.DateTimePicker();
            this.lblBirthdate = new System.Windows.Forms.Label();
            this.rbFemale = new System.Windows.Forms.RadioButton();
            this.rbMale = new System.Windows.Forms.RadioButton();
            this.lblGender = new System.Windows.Forms.Label();
            this.txtUserPass = new System.Windows.Forms.TextBox();
            this.txtUserRole = new System.Windows.Forms.TextBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.lblPassword = new System.Windows.Forms.Label();
            this.txtUserID = new System.Windows.Forms.TextBox();
            this.lblID = new System.Windows.Forms.Label();
            this.lblRole = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txtBDate2 = new System.Windows.Forms.DateTimePicker();
            this.txtGender2 = new System.Windows.Forms.TextBox();
            this.lblEmail2 = new System.Windows.Forms.Label();
            this.txtEmail2 = new System.Windows.Forms.TextBox();
            this.lblPhone2 = new System.Windows.Forms.Label();
            this.txtPhone2 = new System.Windows.Forms.TextBox();
            this.txtBDate22 = new System.Windows.Forms.TextBox();
            this.lblBirthdate2 = new System.Windows.Forms.Label();
            this.lblGender2 = new System.Windows.Forms.Label();
            this.lblPassword2 = new System.Windows.Forms.Label();
            this.txtUserPass2 = new System.Windows.Forms.TextBox();
            this.txtUserRole2 = new System.Windows.Forms.TextBox();
            this.lblID2 = new System.Windows.Forms.Label();
            this.txtUserID2 = new System.Windows.Forms.TextBox();
            this.lblRole2 = new System.Windows.Forms.Label();
            this.lblProfile = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.AutoSize = true;
            this.panel2.BackColor = System.Drawing.SystemColors.Control;
            this.panel2.Controls.Add(this.btnLogout);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.lblCoach);
            this.panel2.Controls.Add(this.lblRecom);
            this.panel2.Controls.Add(this.lblManage);
            this.panel2.Controls.Add(this.lblperform);
            this.panel2.Controls.Add(this.lblPay);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(207, 717);
            this.panel2.TabIndex = 14;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // btnLogout
            // 
            this.btnLogout.Location = new System.Drawing.Point(12, 663);
            this.btnLogout.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(75, 32);
            this.btnLogout.TabIndex = 35;
            this.btnLogout.Text = "Log Out";
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Lavender;
            this.panel4.Controls.Add(this.lblUpdate);
            this.panel4.Location = new System.Drawing.Point(4, 400);
            this.panel4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(188, 49);
            this.panel4.TabIndex = 39;
            // 
            // lblUpdate
            // 
            this.lblUpdate.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold);
            this.lblUpdate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblUpdate.Location = new System.Drawing.Point(3, 11);
            this.lblUpdate.Name = "lblUpdate";
            this.lblUpdate.Size = new System.Drawing.Size(148, 26);
            this.lblUpdate.TabIndex = 16;
            this.lblUpdate.Text = "Update Profile";
            // 
            // lblCoach
            // 
            this.lblCoach.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Bold);
            this.lblCoach.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblCoach.Location = new System.Drawing.Point(3, 11);
            this.lblCoach.Name = "lblCoach";
            this.lblCoach.Size = new System.Drawing.Size(117, 48);
            this.lblCoach.TabIndex = 11;
            this.lblCoach.Text = "Coach";
            // 
            // lblRecom
            // 
            this.lblRecom.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold);
            this.lblRecom.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblRecom.Location = new System.Drawing.Point(7, 332);
            this.lblRecom.Name = "lblRecom";
            this.lblRecom.Size = new System.Drawing.Size(185, 42);
            this.lblRecom.TabIndex = 15;
            this.lblRecom.Text = "\nRecommendation";
            this.lblRecom.Click += new System.EventHandler(this.lblRecom_Click);
            // 
            // lblManage
            // 
            this.lblManage.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold);
            this.lblManage.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblManage.Location = new System.Drawing.Point(7, 153);
            this.lblManage.Name = "lblManage";
            this.lblManage.Size = new System.Drawing.Size(185, 26);
            this.lblManage.TabIndex = 12;
            this.lblManage.Text = "Manage Schedule";
            this.lblManage.Click += new System.EventHandler(this.lblManage_Click);
            // 
            // lblperform
            // 
            this.lblperform.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold);
            this.lblperform.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblperform.Location = new System.Drawing.Point(7, 288);
            this.lblperform.Name = "lblperform";
            this.lblperform.Size = new System.Drawing.Size(197, 26);
            this.lblperform.TabIndex = 14;
            this.lblperform.Text = "Members\' performance";
            this.lblperform.Click += new System.EventHandler(this.lblperform_Click);
            // 
            // lblPay
            // 
            this.lblPay.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold);
            this.lblPay.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblPay.Location = new System.Drawing.Point(7, 222);
            this.lblPay.Name = "lblPay";
            this.lblPay.Size = new System.Drawing.Size(93, 32);
            this.lblPay.TabIndex = 13;
            this.lblPay.Text = "Payment";
            this.lblPay.Click += new System.EventHandler(this.lblPay_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.txtEmail);
            this.panel1.Controls.Add(this.lblEmail);
            this.panel1.Controls.Add(this.txtPhone);
            this.panel1.Controls.Add(this.lblPhone);
            this.panel1.Controls.Add(this.txtBDate);
            this.panel1.Controls.Add(this.lblBirthdate);
            this.panel1.Controls.Add(this.rbFemale);
            this.panel1.Controls.Add(this.rbMale);
            this.panel1.Controls.Add(this.lblGender);
            this.panel1.Controls.Add(this.txtUserPass);
            this.panel1.Controls.Add(this.txtUserRole);
            this.panel1.Controls.Add(this.btnUpdate);
            this.panel1.Controls.Add(this.lblPassword);
            this.panel1.Controls.Add(this.txtUserID);
            this.panel1.Controls.Add(this.lblID);
            this.panel1.Controls.Add(this.lblRole);
            this.panel1.Location = new System.Drawing.Point(219, 50);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(245, 613);
            this.panel1.TabIndex = 37;
            // 
            // txtEmail
            // 
            this.txtEmail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtEmail.Font = new System.Drawing.Font("Arial", 10.2F);
            this.txtEmail.Location = new System.Drawing.Point(25, 430);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(197, 27);
            this.txtEmail.TabIndex = 51;
            // 
            // lblEmail
            // 
            this.lblEmail.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold);
            this.lblEmail.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblEmail.Location = new System.Drawing.Point(21, 399);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(112, 27);
            this.lblEmail.TabIndex = 50;
            this.lblEmail.Text = "Email";
            // 
            // txtPhone
            // 
            this.txtPhone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPhone.Font = new System.Drawing.Font("Arial", 10.2F);
            this.txtPhone.Location = new System.Drawing.Point(25, 369);
            this.txtPhone.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new System.Drawing.Size(197, 27);
            this.txtPhone.TabIndex = 49;
            // 
            // lblPhone
            // 
            this.lblPhone.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold);
            this.lblPhone.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblPhone.Location = new System.Drawing.Point(21, 338);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(112, 27);
            this.lblPhone.TabIndex = 48;
            this.lblPhone.Text = "Phone";
            // 
            // txtBDate
            // 
            this.txtBDate.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txtBDate.Location = new System.Drawing.Point(25, 303);
            this.txtBDate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtBDate.Name = "txtBDate";
            this.txtBDate.Size = new System.Drawing.Size(196, 27);
            this.txtBDate.TabIndex = 47;
            // 
            // lblBirthdate
            // 
            this.lblBirthdate.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold);
            this.lblBirthdate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblBirthdate.Location = new System.Drawing.Point(21, 274);
            this.lblBirthdate.Name = "lblBirthdate";
            this.lblBirthdate.Size = new System.Drawing.Size(112, 27);
            this.lblBirthdate.TabIndex = 46;
            this.lblBirthdate.Text = "Birthdate";
            // 
            // rbFemale
            // 
            this.rbFemale.AutoSize = true;
            this.rbFemale.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbFemale.Location = new System.Drawing.Point(120, 242);
            this.rbFemale.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rbFemale.Name = "rbFemale";
            this.rbFemale.Size = new System.Drawing.Size(78, 21);
            this.rbFemale.TabIndex = 45;
            this.rbFemale.Text = "Female";
            this.rbFemale.UseVisualStyleBackColor = true;
            // 
            // rbMale
            // 
            this.rbMale.AutoSize = true;
            this.rbMale.Checked = true;
            this.rbMale.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbMale.Location = new System.Drawing.Point(25, 242);
            this.rbMale.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rbMale.Name = "rbMale";
            this.rbMale.Size = new System.Drawing.Size(59, 21);
            this.rbMale.TabIndex = 44;
            this.rbMale.TabStop = true;
            this.rbMale.Text = "Male";
            this.rbMale.UseVisualStyleBackColor = true;
            // 
            // lblGender
            // 
            this.lblGender.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold);
            this.lblGender.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblGender.Location = new System.Drawing.Point(21, 217);
            this.lblGender.Name = "lblGender";
            this.lblGender.Size = new System.Drawing.Size(80, 27);
            this.lblGender.TabIndex = 43;
            this.lblGender.Text = "Gender";
            // 
            // txtUserPass
            // 
            this.txtUserPass.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtUserPass.Font = new System.Drawing.Font("Arial", 10.2F);
            this.txtUserPass.Location = new System.Drawing.Point(25, 175);
            this.txtUserPass.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtUserPass.Name = "txtUserPass";
            this.txtUserPass.Size = new System.Drawing.Size(197, 27);
            this.txtUserPass.TabIndex = 42;
            // 
            // txtUserRole
            // 
            this.txtUserRole.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtUserRole.Enabled = false;
            this.txtUserRole.Font = new System.Drawing.Font("Arial", 10.2F);
            this.txtUserRole.Location = new System.Drawing.Point(25, 106);
            this.txtUserRole.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtUserRole.Name = "txtUserRole";
            this.txtUserRole.ReadOnly = true;
            this.txtUserRole.Size = new System.Drawing.Size(197, 27);
            this.txtUserRole.TabIndex = 29;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnUpdate.Location = new System.Drawing.Point(75, 534);
            this.btnUpdate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(101, 42);
            this.btnUpdate.TabIndex = 40;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // lblPassword
            // 
            this.lblPassword.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPassword.Location = new System.Drawing.Point(21, 145);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(159, 27);
            this.lblPassword.TabIndex = 27;
            this.lblPassword.Text = "User Password";
            // 
            // txtUserID
            // 
            this.txtUserID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtUserID.Enabled = false;
            this.txtUserID.Font = new System.Drawing.Font("Arial", 10.2F);
            this.txtUserID.Location = new System.Drawing.Point(25, 39);
            this.txtUserID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtUserID.Name = "txtUserID";
            this.txtUserID.ReadOnly = true;
            this.txtUserID.Size = new System.Drawing.Size(197, 27);
            this.txtUserID.TabIndex = 23;
            // 
            // lblID
            // 
            this.lblID.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold);
            this.lblID.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblID.Location = new System.Drawing.Point(21, 10);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(112, 27);
            this.lblID.TabIndex = 22;
            this.lblID.Text = "User ID";
            // 
            // lblRole
            // 
            this.lblRole.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold);
            this.lblRole.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblRole.Location = new System.Drawing.Point(21, 81);
            this.lblRole.Name = "lblRole";
            this.lblRole.Size = new System.Drawing.Size(112, 27);
            this.lblRole.TabIndex = 9;
            this.lblRole.Text = "User Role";
            // 
            // lblTitle
            // 
            this.lblTitle.Font = new System.Drawing.Font("Arial Narrow", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblTitle.Location = new System.Drawing.Point(211, 1);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(249, 48);
            this.lblTitle.TabIndex = 18;
            this.lblTitle.Text = "Update Profile";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.txtBDate2);
            this.panel3.Controls.Add(this.txtGender2);
            this.panel3.Controls.Add(this.lblEmail2);
            this.panel3.Controls.Add(this.txtEmail2);
            this.panel3.Controls.Add(this.lblPhone2);
            this.panel3.Controls.Add(this.txtPhone2);
            this.panel3.Controls.Add(this.txtBDate22);
            this.panel3.Controls.Add(this.lblBirthdate2);
            this.panel3.Controls.Add(this.lblGender2);
            this.panel3.Controls.Add(this.lblPassword2);
            this.panel3.Controls.Add(this.txtUserPass2);
            this.panel3.Controls.Add(this.txtUserRole2);
            this.panel3.Controls.Add(this.lblID2);
            this.panel3.Controls.Add(this.txtUserID2);
            this.panel3.Controls.Add(this.lblRole2);
            this.panel3.Location = new System.Drawing.Point(511, 52);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(559, 612);
            this.panel3.TabIndex = 38;
            // 
            // txtBDate2
            // 
            this.txtBDate2.Enabled = false;
            this.txtBDate2.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBDate2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txtBDate2.Location = new System.Drawing.Point(230, 334);
            this.txtBDate2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtBDate2.Name = "txtBDate2";
            this.txtBDate2.Size = new System.Drawing.Size(196, 27);
            this.txtBDate2.TabIndex = 52;
            // 
            // txtGender2
            // 
            this.txtGender2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtGender2.Enabled = false;
            this.txtGender2.Font = new System.Drawing.Font("Arial", 10.2F);
            this.txtGender2.Location = new System.Drawing.Point(229, 265);
            this.txtGender2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtGender2.Name = "txtGender2";
            this.txtGender2.ReadOnly = true;
            this.txtGender2.Size = new System.Drawing.Size(197, 27);
            this.txtGender2.TabIndex = 60;
            this.txtGender2.TabStop = false;
            // 
            // lblEmail2
            // 
            this.lblEmail2.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmail2.Location = new System.Drawing.Point(128, 462);
            this.lblEmail2.Name = "lblEmail2";
            this.lblEmail2.Size = new System.Drawing.Size(84, 27);
            this.lblEmail2.TabIndex = 58;
            this.lblEmail2.Text = "Email:";
            // 
            // txtEmail2
            // 
            this.txtEmail2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtEmail2.Enabled = false;
            this.txtEmail2.Font = new System.Drawing.Font("Arial", 10.2F);
            this.txtEmail2.Location = new System.Drawing.Point(229, 458);
            this.txtEmail2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtEmail2.Name = "txtEmail2";
            this.txtEmail2.ReadOnly = true;
            this.txtEmail2.Size = new System.Drawing.Size(197, 27);
            this.txtEmail2.TabIndex = 59;
            this.txtEmail2.TabStop = false;
            // 
            // lblPhone2
            // 
            this.lblPhone2.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhone2.Location = new System.Drawing.Point(128, 399);
            this.lblPhone2.Name = "lblPhone2";
            this.lblPhone2.Size = new System.Drawing.Size(84, 27);
            this.lblPhone2.TabIndex = 56;
            this.lblPhone2.Text = "Phone:";
            // 
            // txtPhone2
            // 
            this.txtPhone2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPhone2.Enabled = false;
            this.txtPhone2.Font = new System.Drawing.Font("Arial", 10.2F);
            this.txtPhone2.Location = new System.Drawing.Point(229, 396);
            this.txtPhone2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtPhone2.Name = "txtPhone2";
            this.txtPhone2.ReadOnly = true;
            this.txtPhone2.Size = new System.Drawing.Size(197, 27);
            this.txtPhone2.TabIndex = 57;
            this.txtPhone2.TabStop = false;
            // 
            // txtBDate22
            // 
            this.txtBDate22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBDate22.Enabled = false;
            this.txtBDate22.Font = new System.Drawing.Font("Arial", 10.2F);
            this.txtBDate22.Location = new System.Drawing.Point(229, 334);
            this.txtBDate22.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtBDate22.Name = "txtBDate22";
            this.txtBDate22.ReadOnly = true;
            this.txtBDate22.Size = new System.Drawing.Size(197, 27);
            this.txtBDate22.TabIndex = 55;
            this.txtBDate22.TabStop = false;
            // 
            // lblBirthdate2
            // 
            this.lblBirthdate2.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold);
            this.lblBirthdate2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblBirthdate2.Location = new System.Drawing.Point(105, 338);
            this.lblBirthdate2.Name = "lblBirthdate2";
            this.lblBirthdate2.Size = new System.Drawing.Size(117, 27);
            this.lblBirthdate2.TabIndex = 52;
            this.lblBirthdate2.Text = "Birthdate:";
            // 
            // lblGender2
            // 
            this.lblGender2.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold);
            this.lblGender2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblGender2.Location = new System.Drawing.Point(117, 267);
            this.lblGender2.Name = "lblGender2";
            this.lblGender2.Size = new System.Drawing.Size(105, 27);
            this.lblGender2.TabIndex = 52;
            this.lblGender2.Text = "Gender:";
            // 
            // lblPassword2
            // 
            this.lblPassword2.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPassword2.Location = new System.Drawing.Point(57, 203);
            this.lblPassword2.Name = "lblPassword2";
            this.lblPassword2.Size = new System.Drawing.Size(165, 27);
            this.lblPassword2.TabIndex = 52;
            this.lblPassword2.Text = "User Password:";
            // 
            // txtUserPass2
            // 
            this.txtUserPass2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtUserPass2.Enabled = false;
            this.txtUserPass2.Font = new System.Drawing.Font("Arial", 10.2F);
            this.txtUserPass2.Location = new System.Drawing.Point(229, 199);
            this.txtUserPass2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtUserPass2.Name = "txtUserPass2";
            this.txtUserPass2.ReadOnly = true;
            this.txtUserPass2.Size = new System.Drawing.Size(197, 27);
            this.txtUserPass2.TabIndex = 54;
            this.txtUserPass2.TabStop = false;
            // 
            // txtUserRole2
            // 
            this.txtUserRole2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtUserRole2.Enabled = false;
            this.txtUserRole2.Font = new System.Drawing.Font("Arial", 10.2F);
            this.txtUserRole2.Location = new System.Drawing.Point(229, 130);
            this.txtUserRole2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtUserRole2.Name = "txtUserRole2";
            this.txtUserRole2.ReadOnly = true;
            this.txtUserRole2.Size = new System.Drawing.Size(197, 27);
            this.txtUserRole2.TabIndex = 53;
            this.txtUserRole2.TabStop = false;
            // 
            // lblID2
            // 
            this.lblID2.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold);
            this.lblID2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblID2.Location = new System.Drawing.Point(132, 66);
            this.lblID2.Name = "lblID2";
            this.lblID2.Size = new System.Drawing.Size(91, 27);
            this.lblID2.TabIndex = 52;
            this.lblID2.Text = "User ID:";
            // 
            // txtUserID2
            // 
            this.txtUserID2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtUserID2.Enabled = false;
            this.txtUserID2.Font = new System.Drawing.Font("Arial", 10.2F);
            this.txtUserID2.Location = new System.Drawing.Point(229, 60);
            this.txtUserID2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtUserID2.Name = "txtUserID2";
            this.txtUserID2.ReadOnly = true;
            this.txtUserID2.Size = new System.Drawing.Size(197, 27);
            this.txtUserID2.TabIndex = 52;
            this.txtUserID2.TabStop = false;
            // 
            // lblRole2
            // 
            this.lblRole2.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold);
            this.lblRole2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblRole2.Location = new System.Drawing.Point(117, 135);
            this.lblRole2.Name = "lblRole2";
            this.lblRole2.Size = new System.Drawing.Size(123, 27);
            this.lblRole2.TabIndex = 52;
            this.lblRole2.Text = "User Role:";
            // 
            // lblProfile
            // 
            this.lblProfile.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProfile.Location = new System.Drawing.Point(720, 19);
            this.lblProfile.Name = "lblProfile";
            this.lblProfile.Size = new System.Drawing.Size(172, 31);
            this.lblProfile.TabIndex = 39;
            this.lblProfile.Text = "Current Profile";
            // 
            // frmupdate_coach
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1099, 717);
            this.Controls.Add(this.lblProfile);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "frmupdate_coach";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Update Profile";
            this.Load += new System.EventHandler(this.frmupdate_Load);
            this.panel2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblUpdate;
        private System.Windows.Forms.Label lblCoach;
        private System.Windows.Forms.Label lblRecom;
        private System.Windows.Forms.Label lblManage;
        private System.Windows.Forms.Label lblperform;
        private System.Windows.Forms.Label lblPay;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtUserPass;
        private System.Windows.Forms.TextBox txtUserRole;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.TextBox txtUserID;
        private System.Windows.Forms.Label lblID;
        private System.Windows.Forms.Label lblRole;
        private System.Windows.Forms.RadioButton rbFemale;
        private System.Windows.Forms.RadioButton rbMale;
        private System.Windows.Forms.Label lblGender;
        private System.Windows.Forms.Label lblBirthdate;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.TextBox txtPhone;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.DateTimePicker txtBDate;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txtBDate22;
        private System.Windows.Forms.Label lblBirthdate2;
        private System.Windows.Forms.Label lblGender2;
        private System.Windows.Forms.Label lblPassword2;
        private System.Windows.Forms.TextBox txtUserPass2;
        private System.Windows.Forms.TextBox txtUserRole2;
        private System.Windows.Forms.Label lblID2;
        private System.Windows.Forms.TextBox txtUserID2;
        private System.Windows.Forms.Label lblRole2;
        private System.Windows.Forms.Label lblEmail2;
        private System.Windows.Forms.TextBox txtEmail2;
        private System.Windows.Forms.Label lblPhone2;
        private System.Windows.Forms.TextBox txtPhone2;
        private System.Windows.Forms.TextBox txtGender2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Label lblProfile;
        private System.Windows.Forms.DateTimePicker txtBDate2;
    }
}