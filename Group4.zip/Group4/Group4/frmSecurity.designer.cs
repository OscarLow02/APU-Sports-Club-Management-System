﻿namespace Group4
{
    partial class frmSecurity
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cboxQ1 = new System.Windows.Forms.ComboBox();
            this.cboxQ2 = new System.Windows.Forms.ComboBox();
            this.tboxA1 = new System.Windows.Forms.TextBox();
            this.tboxA2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // cboxQ1
            // 
            this.cboxQ1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboxQ1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboxQ1.FormattingEnabled = true;
            this.cboxQ1.Items.AddRange(new object[] {
            "What color do you like the most?",
            "What’s your favorite artist?",
            "What book do you recommend to your friends?",
            "What was the name of your first school teacher?",
            "What is your grandmother’s maiden name?",
            "Which teacher did you like the most at school?"});
            this.cboxQ1.Location = new System.Drawing.Point(262, 118);
            this.cboxQ1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cboxQ1.Name = "cboxQ1";
            this.cboxQ1.Size = new System.Drawing.Size(425, 30);
            this.cboxQ1.TabIndex = 0;
            // 
            // cboxQ2
            // 
            this.cboxQ2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboxQ2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboxQ2.FormattingEnabled = true;
            this.cboxQ2.Items.AddRange(new object[] {
            "What was the name of your favorite childhood pet?",
            "What is your favorite sport?",
            "In which area of the city is your place of work located?",
            "What’s your favorite TV program?",
            "What was the first exam you failed?",
            "What was the name of your elementary school?",
            "What was your favorite food as a child?"});
            this.cboxQ2.Location = new System.Drawing.Point(262, 215);
            this.cboxQ2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cboxQ2.Name = "cboxQ2";
            this.cboxQ2.Size = new System.Drawing.Size(425, 30);
            this.cboxQ2.TabIndex = 1;
            // 
            // tboxA1
            // 
            this.tboxA1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tboxA1.Location = new System.Drawing.Point(262, 158);
            this.tboxA1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tboxA1.Name = "tboxA1";
            this.tboxA1.Size = new System.Drawing.Size(299, 28);
            this.tboxA1.TabIndex = 2;
            // 
            // tboxA2
            // 
            this.tboxA2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tboxA2.Location = new System.Drawing.Point(262, 254);
            this.tboxA2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tboxA2.Name = "tboxA2";
            this.tboxA2.Size = new System.Drawing.Size(299, 28);
            this.tboxA2.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(61, 118);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(178, 24);
            this.label1.TabIndex = 4;
            this.label1.Text = "Security Question 1:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(61, 215);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(178, 24);
            this.label2.TabIndex = 5;
            this.label2.Text = "Security Question 2:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(167, 158);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 24);
            this.label3.TabIndex = 6;
            this.label3.Text = "Answer:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(167, 254);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 24);
            this.label4.TabIndex = 7;
            this.label4.Text = "Answer:";
            // 
            // btnConfirm
            // 
            this.btnConfirm.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConfirm.Location = new System.Drawing.Point(333, 332);
            this.btnConfirm.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(102, 34);
            this.btnConfirm.TabIndex = 8;
            this.btnConfirm.Text = "Confirm";
            this.btnConfirm.UseVisualStyleBackColor = true;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label5.Location = new System.Drawing.Point(246, 52);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(318, 29);
            this.label5.TabIndex = 9;
            this.label5.Text = "Set Up Security Questions";
            // 
            // frmSecurity
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(800, 408);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnConfirm);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tboxA2);
            this.Controls.Add(this.tboxA1);
            this.Controls.Add(this.cboxQ2);
            this.Controls.Add(this.cboxQ1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "frmSecurity";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Security Question";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cboxQ1;
        private System.Windows.Forms.ComboBox cboxQ2;
        private System.Windows.Forms.TextBox tboxA1;
        private System.Windows.Forms.TextBox tboxA2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnConfirm;
        private System.Windows.Forms.Label label5;
    }
}